*****2025.1.18更新文件
1.invert_pendulum_D1文件是最初始的文件，角度为顺时针增加，平衡位置为0度。（Xp = X + l*Sin[q];）并且线性化了Sin(q)->q;

2.invert_pendulum_F2voltage 文件将倒立摆小车系统的直流电机输出，从力转化为电压值，得到的数学模型

****此上的文件都是给LQR使用的

3.invert_pendulum_MPC_D1是无线性化的，直接将结果公式复制进入MPC中使用


4. invert_pendulum_F2voltage文件是根据转矩平衡和带传动距离和小车移动距离相等得出，F = ???ddx+???dx+???ua(电压)的关系式子

5. invert_pendulum_D1_voltage是将invert_pendulum_F2voltage文件得出的F与ua的等式引入拉格朗日方程，求的ddx，ddp->求状态转移矩阵A

----->拉格朗日方程可用于建立数学模型，F和u的关系仅仅影响ddx的等式，但是求解ddx，ddp，ddq都会受影响